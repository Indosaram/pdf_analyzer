zip app.zip *.py main.spec run.sh
pip insntall torch nltk transformers